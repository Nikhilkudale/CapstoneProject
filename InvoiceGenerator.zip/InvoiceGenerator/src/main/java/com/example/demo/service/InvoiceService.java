package com.example.demo.service;

import com.example.demo.entity.Invoice;

import java.util.List;

public interface InvoiceService {
    void addInvoice(Invoice invoice);

    List<Invoice> getAllInvoices();

    void updateInvoice(Invoice updatedInvoice);

    List<Invoice> getInvoicesByUsername(String username);

    void deleteInvoice(Long clientId);

    Invoice getInvoiceByClientId(Long clientId);
    
    List<Invoice> getInvoicesByUserId(Long userId);
}
