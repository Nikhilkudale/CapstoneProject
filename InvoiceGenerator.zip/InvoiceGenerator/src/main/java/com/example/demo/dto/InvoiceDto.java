package com.example.demo.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

public class InvoiceDto {

    @NotBlank(message = "Client name is mandatory")
    private String clientName;

    @Positive(message = "Amount must be positive")
    @NotNull(message = "Amount is mandatory")
    private Double amount;

    @NotBlank(message = "Invoice date is mandatory")
    private String invoiceDate;

    @NotBlank(message = "Description is mandatory")
    private String description;

    // Default constructor
    public InvoiceDto() {
    }

    // Parameterized constructor
    public InvoiceDto(String clientName, Double amount, String invoiceDate, String description) {
        this.clientName = clientName;
        this.amount = amount;
        this.invoiceDate = invoiceDate;
        this.description = description;
    }

    // Getters and setters
    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
