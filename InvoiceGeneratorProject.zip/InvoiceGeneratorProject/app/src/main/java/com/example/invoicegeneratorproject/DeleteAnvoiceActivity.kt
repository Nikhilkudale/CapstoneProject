
package com.example.invoicegeneratorproject

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.invoicegeneratorproject.services.InvoiceService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.lifecycle.lifecycleScope
import android.app.AlertDialog
import android.view.LayoutInflater

class DeleteAnvoiceActivity : AppCompatActivity() {

    private val invoiceService: InvoiceService by lazy {
        RetrofitInstance.retrofit.create(InvoiceService::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_delete_invoice)

        val clientId = intent.getLongExtra("CLIENT_ID", -1)
        val clientName = intent.getStringExtra("CLIENT_NAME")
        val amount = intent.getDoubleExtra("AMOUNT", 0.0)
        val invoiceDate = intent.getStringExtra("INVOICE_DATE")
        val description = intent.getStringExtra("DESCRIPTION")

        findViewById<TextView>(R.id.tv_clientName).text = clientName
        findViewById<TextView>(R.id.tvSingle_amount).text = amount.toString()
        findViewById<TextView>(R.id.tvSingle_date).text = invoiceDate
        findViewById<TextView>(R.id.tv_scrollable_text).text = description

        findViewById<Button>(R.id.deleteButton).setOnClickListener {
            showDeleteConfirmationDialog(clientId)
        }
    }

    private fun showDeleteConfirmationDialog(clientId: Long) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_delete_confirmation, null)
        val builder = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)

        val alertDialog = builder.create()

        dialogView.findViewById<Button>(R.id.btn_yes).setOnClickListener {
            alertDialog.dismiss()
            lifecycleScope.launch {
                try {
                    val response = withContext(Dispatchers.IO) {
                        invoiceService.deleteInvoice(clientId)
                    }
                    if (response.isSuccessful) {
                        Toast.makeText(this@DeleteAnvoiceActivity, "Invoice deleted successfully!", Toast.LENGTH_SHORT).show()
                        navigateToInvoiceList()
                    } else {
                        showToast("Deletion Error: ${response.message()}")
                    }
                } catch (e: Exception) {
                    navigateToInvoiceList()

                }
            }
        }

        dialogView.findViewById<Button>(R.id.btn_no).setOnClickListener {
            alertDialog.dismiss()
        }

        alertDialog.show()
    }

    private fun navigateToInvoiceList() {
        val intent = Intent(this@DeleteAnvoiceActivity, ListingInvoiceActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun showToast(message: String) {
        Toast.makeText(this@DeleteAnvoiceActivity, message, Toast.LENGTH_SHORT).show()
    }
}


























//package com.example.invoicegeneratorproject
//
//import android.content.Intent
//import android.os.Bundle
//import android.widget.Button
//import android.widget.TextView
//import android.widget.Toast
//import androidx.appcompat.app.AppCompatActivity
//import com.example.invoicegeneratorproject.services.InvoiceService
//import kotlinx.coroutines.CoroutineScope
//import kotlinx.coroutines.Dispatchers
//import kotlinx.coroutines.launch
//import kotlinx.coroutines.withContext
//import retrofit2.Retrofit
//import retrofit2.converter.gson.GsonConverterFactory
//import android.app.AlertDialog
//import android.view.LayoutInflater
//
//class DeleteAnvoiceActivity : AppCompatActivity() {
//
//    private val invoiceService = RetrofitInstance.retrofit.create(InvoiceService::class.java)
//    private val mainScope = CoroutineScope(Dispatchers.Main)
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_delete_invoice)
//
//        val clientId = intent.getLongExtra("CLIENT_ID", -1)
//        val clientName = intent.getStringExtra("CLIENT_NAME")
//        val amount = intent.getDoubleExtra("AMOUNT", 0.0)
//        val invoiceDate = intent.getStringExtra("INVOICE_DATE")
//        val description = intent.getStringExtra("DESCRIPTION")
//
//        findViewById<TextView>(R.id.tv_clientName).text = clientName
//        findViewById<TextView>(R.id.tvSingle_amount).text = amount.toString()
//        findViewById<TextView>(R.id.tvSingle_date).text = invoiceDate
//        findViewById<TextView>(R.id.tv_scrollable_text).text = description
//
//        findViewById<Button>(R.id.deleteButton).setOnClickListener {
//            showDeleteConfirmationDialog(clientId)
//        }
//    }
//
//    private fun showDeleteConfirmationDialog(clientId: Long) {
//        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_delete_confirmation, null)
//        val builder = AlertDialog.Builder(this)
//            .setView(dialogView)
//            .setCancelable(false)
//
//        val alertDialog = builder.create()
//
//        dialogView.findViewById<Button>(R.id.btn_yes).setOnClickListener {
//            alertDialog.dismiss()
//            mainScope.launch {
//                try {
//                    val response = withContext(Dispatchers.IO) {
//                        invoiceService.deleteInvoice(clientId)
//
//                        val intent = Intent(this@CreateInvoiceActivity, InvoiceListActivity::class.java).apply {
//
//                        }
//                        startActivity(intent)
//                        finish()
//                    }
//                    if (response.isSuccessful) {
//                        Toast.makeText(this@DeleteAnvoiceActivity, "Deleted", Toast.LENGTH_SHORT).show()
//                        val intent = Intent(this@DeleteAnvoiceActivity, InvoiceListActivity::class.java)
//                        startActivity(intent)
//                        finish()
//                    } else {
//                        Toast.makeText(this@DeleteAnvoiceActivity, "Deletion Error!", Toast.LENGTH_SHORT).show()
//                    }
//                } catch (e: Exception) {
//                    Toast.makeText(this@DeleteAnvoiceActivity, "Success", Toast.LENGTH_SHORT).show()
//                }
//            }
//        }
//
//        dialogView.findViewById<Button>(R.id.btn_no).setOnClickListener {
//            alertDialog.dismiss()
//        }
//
//        alertDialog.show()
//    }
//}