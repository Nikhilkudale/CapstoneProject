package com.example.invoicegeneratorproject

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.invoicegeneratorproject.data.Invoice
import com.example.invoicegeneratorproject.services.InvoiceService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

class UpdateInvoiceActivity : AppCompatActivity() {

    private val invoiceService: InvoiceService by lazy {
        RetrofitInstance.retrofit.create(InvoiceService::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_invoice)

        val clientId = intent.getLongExtra("CLIENT_ID", -1)
        val clientName = intent.getStringExtra("CLIENT_NAME")
        val amount = intent.getDoubleExtra("AMOUNT", 0.0)
        val description = intent.getStringExtra("DESCRIPTION")
        val invoiceDate = intent.getStringExtra("INVOICE_DATE")

        val clientNameEditText: EditText = findViewById(R.id.et_client_name)
        val amountEditText: EditText = findViewById(R.id.et_amount)
        val descriptionEditText: EditText = findViewById(R.id.et_description)
        val invoiceDateEditText: EditText = findViewById(R.id.et_date)

        clientNameEditText.setText(clientName)
        amountEditText.setText(amount.toString())
        descriptionEditText.setText(description)
        invoiceDateEditText.setText(invoiceDate)

        // Set up the date picker
        invoiceDateEditText.setOnClickListener {
            showDatePicker()
        }

        findViewById<Button>(R.id.updateButton).setOnClickListener {
            val updatedClientName = clientNameEditText.text.toString()
            val updatedAmount = amountEditText.text.toString().toDoubleOrNull()
            val updatedDescription = descriptionEditText.text.toString()
            val updatedInvoiceDate = invoiceDateEditText.text.toString()

            if (validateInputs(updatedClientName, updatedAmount, updatedDescription, updatedInvoiceDate)) {
                val updatedInvoice = Invoice(clientId, null, updatedClientName, updatedAmount!!, updatedDescription, updatedInvoiceDate)
                updateInvoice(updatedInvoice)
            } else {
                showToast("Please fill all fields correctly.")
            }
        }
    }

    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDay ->
                val selectedDate = "$selectedYear-${selectedMonth + 1}-$selectedDay"
                findViewById<EditText>(R.id.et_date).setText(selectedDate)
            },
            year, month, day
        )

        // Set the maximum date to today
        datePickerDialog.datePicker.maxDate = calendar.timeInMillis

        datePickerDialog.show()
    }

    private fun validateInputs(
        clientName: String,
        amount: Double?,
        description: String,
        invoiceDate: String
    ): Boolean {
        return clientName.isNotBlank() && amount != null && amount > 0 && description.isNotBlank() && invoiceDate.isNotBlank()
    }

    private fun updateInvoice(invoice: Invoice) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val response = invoiceService.updateInvoice(invoice, invoice.clientId!!)
                withContext(Dispatchers.Main) {
                    if (response.isSuccessful) {
                        showToast("Invoice updated successfully")

                    } else {
                        showToast("Failed to update invoice: ${response.message()}")
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    navigateToInvoiceList()

                }
            }
        }
    }

    private fun navigateToInvoiceList() {
        val intent = Intent(this@UpdateInvoiceActivity, ListingInvoiceActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun showToast(message: String) {
        Toast.makeText(this@UpdateInvoiceActivity, message, Toast.LENGTH_SHORT).show()
    }
}


















//package com.example.invoicegeneratorproject
//
//import android.app.DatePickerDialog
//import android.content.Intent
//import android.os.Bundle
//import android.widget.Button
//import android.widget.EditText
//import android.widget.Toast
//import androidx.appcompat.app.AppCompatActivity
//import androidx.lifecycle.lifecycleScope
//import com.example.invoicegeneratorproject.data.Invoice
//import com.example.invoicegeneratorproject.services.InvoiceService
//import kotlinx.coroutines.Dispatchers
//import kotlinx.coroutines.launch
//import kotlinx.coroutines.withContext
//import java.util.Calendar
//
//class UpdateInvoiceActivity : AppCompatActivity() {
//
//    private val invoiceService: InvoiceService by lazy {
//        RetrofitInstance.retrofit.create(InvoiceService::class.java)
//    }
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_update_invoice)
//
//        val clientId = intent.getLongExtra("CLIENT_ID", -1)
//        val clientName = intent.getStringExtra("CLIENT_NAME")
//        val amount = intent.getDoubleExtra("AMOUNT", 0.0)
//        val description = intent.getStringExtra("DESCRIPTION")
//        val invoiceDate = intent.getStringExtra("INVOICE_DATE")
//
//        val clientNameEditText: EditText = findViewById(R.id.et_client_name)
//        val amountEditText: EditText = findViewById(R.id.et_amount)
//        val descriptionEditText: EditText = findViewById(R.id.et_description)
//        val invoiceDateEditText: EditText = findViewById(R.id.et_date)
//
//        clientNameEditText.setText(clientName)
//        amountEditText.setText(amount.toString())
//        descriptionEditText.setText(description)
//        invoiceDateEditText.setText(invoiceDate)
//
//        findViewById<Button>(R.id.updateButton).setOnClickListener {
//            val updatedClientName = clientNameEditText.text.toString()
//            val updatedAmount = amountEditText.text.toString().toDoubleOrNull()
//            val updatedDescription = descriptionEditText.text.toString()
//            val updatedInvoiceDate = invoiceDateEditText.text.toString()
//
//            if (validateInputs(updatedClientName, updatedAmount, updatedDescription, updatedInvoiceDate)) {
//                val updatedInvoice = Invoice(clientId, null, updatedClientName, updatedAmount!!, updatedDescription, updatedInvoiceDate)
//                updateInvoice(updatedInvoice)
//
//            } else {
//                showToast("Please fill all fields correctly.")
//            }
//        }
//    }
//
//    private fun showDatePicker() {
//        val calendar = Calendar.getInstance()
//        val year = calendar.get(Calendar.YEAR)
//        val month = calendar.get(Calendar.MONTH)
//        val day = calendar.get(Calendar.DAY_OF_MONTH)
//
//        val datePickerDialog = DatePickerDialog(
//            this,
//            { _, selectedYear, selectedMonth, selectedDay ->
//                val selectedDate = "$selectedYear-${selectedMonth + 1}-$selectedDay"
//                invoiceDateEditText.setText(selectedDate)
//            },
//            year, month, day
//        )
//
//        // Set the maximum date to today
//        datePickerDialog.datePicker.maxDate = calendar.timeInMillis
//
//        datePickerDialog.show()
//    }
//
//    private fun validateInputs(
//        clientName: String,
//        amount: Double?,
//        description: String,
//        invoiceDate: String
//    ): Boolean {
//        return clientName.isNotBlank() && amount != null && amount > 0 && description.isNotBlank() && invoiceDate.isNotBlank()
//    }
//
//    private fun updateInvoice(invoice: Invoice) {
//        lifecycleScope.launch(Dispatchers.IO) {
//            try {
//                val response = invoiceService.updateInvoice(invoice, invoice.clientId!!)
//                withContext(Dispatchers.Main) {
//                    if (response.isSuccessful) {
//                        showToast("Invoice updated successfully")
//                        navigateToInvoiceList()
//                    } else {
//                        showToast("Failed to update invoice: ${response.message()}")
//                    }
//                }
//            } catch (e: Exception) {
//                withContext(Dispatchers.Main) {
//                    navigateToInvoiceList()
//
//                }
//            }
//        }
//    }
//
//    private fun navigateToInvoiceList() {
//        val intent = Intent(this@UpdateInvoiceActivity, ListingInvoiceActivity::class.java)
//        startActivity(intent)
//        finish()
//    }
//
//    private fun showToast(message: String) {
//        Toast.makeText(this@UpdateInvoiceActivity, message, Toast.LENGTH_SHORT).show()
//    }
//}
