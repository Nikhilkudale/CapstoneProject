package com.example.invoicegeneratorproject

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.invoicegeneratorproject.data.Invoice
import com.example.invoicegeneratorproject.data.PreferenceHelper
import com.example.invoicegeneratorproject.services.InvoiceService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

class CreateInvoiceActivity : AppCompatActivity() {

    private lateinit var clientNameEditText: EditText
    private lateinit var amountEditText: EditText
    private lateinit var descriptionEditText: EditText
    private lateinit var invoiceDateEditText: EditText
    private lateinit var addInvoiceButton: Button

    private val invoiceService: InvoiceService by lazy {
        RetrofitInstance.retrofit.create(InvoiceService::class.java)
    }

    private var userId: Long = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.invoice_create_layout)


        // Retrieve the actual user ID from shared preferences or any other storage
        userId = PreferenceHelper.getUserId(this)

        clientNameEditText = findViewById(R.id.clientNameEditText)
        amountEditText = findViewById(R.id.amountEditText)
        descriptionEditText = findViewById(R.id.descriptionEditText)
        invoiceDateEditText = findViewById(R.id.dateEditText)
        addInvoiceButton = findViewById(R.id.addInvoiceButton)

        invoiceDateEditText.setOnClickListener {
            showDatePicker()
        }

        addInvoiceButton.setOnClickListener {
            val clientName = clientNameEditText.text.toString()
            val amountText = amountEditText.text.toString()
            val amount = amountText.toDoubleOrNull()
            val description = descriptionEditText.text.toString()
            val invoiceDate = invoiceDateEditText.text.toString()

            if (validateInputs(clientName, amount, description, invoiceDate)) {
                val invoice = Invoice(clientId = null, userId = null, clientName, amount!!, description, invoiceDate)
                saveInvoiceToBackend(invoice)
            } else {
                showToast("Please fill all fields correctly.")
            }
        }
    }

    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDay ->
                val selectedDate = "$selectedYear-${selectedMonth + 1}-$selectedDay"
                invoiceDateEditText.setText(selectedDate)
            },
            year, month, day
        )

        // Set the maximum date to today
        datePickerDialog.datePicker.maxDate = calendar.timeInMillis

        datePickerDialog.show()
    }

    private fun validateInputs(
        clientName: String,
        amount: Double?,
        description: String,
        invoiceDate: String
    ): Boolean {
        return clientName.isNotBlank() && amount != null && amount > 0 && description.isNotBlank() && invoiceDate.isNotBlank()
    }

    private fun saveInvoiceToBackend(invoice: Invoice) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val response = invoiceService.addInvoice(invoice, userId)
                withContext(Dispatchers.Main) {
                    if (response.isSuccessful) {
                        showToast("Invoice added successfully.")
                        navigateToInvoiceList()
                    } else {
                        showToast("Error adding invoice: ${response.message()}")
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    navigateToInvoiceList()

                }
            }
        }
    }

    private fun navigateToInvoiceList() {
        val intent = Intent(this@CreateInvoiceActivity, ListingInvoiceActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun showToast(message: String) {
        Toast.makeText(this@CreateInvoiceActivity, message, Toast.LENGTH_SHORT).show()
    }
}
































//package com.example.invoicegeneratorproject
//
//import android.content.Intent
//import android.os.Bundle
//import android.widget.Button
//import android.widget.EditText
//import android.widget.Toast
//import androidx.appcompat.app.AppCompatActivity
//import androidx.lifecycle.lifecycleScope
//import com.example.invoicegeneratorproject.data.Invoice
//import com.example.invoicegeneratorproject.data.PreferenceHelper
//import com.example.invoicegeneratorproject.services.InvoiceService
//import kotlinx.coroutines.Dispatchers
//import kotlinx.coroutines.launch
//import kotlinx.coroutines.withContext
//
//class CreateInvoiceActivity : AppCompatActivity() {
//
//    private lateinit var clientNameEditText: EditText
//    private lateinit var amountEditText: EditText
//    private lateinit var descriptionEditText: EditText
//    private lateinit var invoiceDateEditText: EditText
//    private lateinit var addInvoiceButton: Button
//
//    private val invoiceService: InvoiceService by lazy {
//        RetrofitInstance.retrofit.create(InvoiceService::class.java)
//    }
//
//    private var userId: Long = -1
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.invoice_create_layout)
//
//        userId = PreferenceHelper.getUserId(this)
//
//        clientNameEditText = findViewById(R.id.clientNameEditText)
//        amountEditText = findViewById(R.id.amountEditText)
//        descriptionEditText = findViewById(R.id.descriptionEditText)
//        invoiceDateEditText = findViewById(R.id.dateEditText)
//        addInvoiceButton = findViewById(R.id.addInvoiceButton)
//
//        addInvoiceButton.setOnClickListener {
//            val clientName = clientNameEditText.text.toString()
//            val amountText = amountEditText.text.toString()
//            val amount = amountText.toDoubleOrNull()
//            val description = descriptionEditText.text.toString()
//            val invoiceDate = invoiceDateEditText.text.toString()
//
//            if (validateInputs(clientName, amount, description, invoiceDate)) {
//                val invoice = Invoice(clientId = null, userId = null,clientName, amount!!, description, invoiceDate)
//                saveInvoiceToBackend(invoice)
//            } else {
//                showToast("Please fill all fields correctly.")
//            }
//        }
//    }
//
//    private fun validateInputs(
//        clientName: String,
//        amount: Double?,
//        description: String,
//        invoiceDate: String
//    ): Boolean {
//        return clientName.isNotBlank() && amount != null && amount > 0 && description.isNotBlank() && invoiceDate.isNotBlank()
//    }
//
//    private fun saveInvoiceToBackend(invoice: Invoice) {
//        lifecycleScope.launch(Dispatchers.IO) {
//            try {
//                val response = invoiceService.addInvoice(invoice, userId)
//                withContext(Dispatchers.Main) {
//                    if (response.isSuccessful) {
//                        showToast("")
//                        navigateToInvoiceList()
//                    } else {
//                        showToast("Error adding invoice: ${response.message()}")
//                    }
//                }
//            } catch (e: Exception) {
//                withContext(Dispatchers.Main) {
//                    showToast("")
//                    navigateToInvoiceList()
//
//                }
//            }
//        }
//    }
//
//
//
//
//
//
//
//
//
//
//    private fun navigateToInvoiceList() {
//        val intent = Intent(this@CreateInvoiceActivity, ListingInvoiceActivity::class.java)
//        startActivity(intent)
//        finish()
//    }
//
//    private fun showToast(message: String) {
//        Toast.makeText(this@CreateInvoiceActivity, message, Toast.LENGTH_SHORT).show()
//    }
//}













